package com.njue.mis.handler;

import java.util.Vector;

import com.njue.mis.model.StorageGoods;

public interface StorageGoodsHandler
{
	public Vector<StorageGoods> getAllStorageGoods();
}
