/**
 * �˻���
 */

package com.njue.mis.model;


public class PortOut extends Port
{

	public PortOut()
	{
		super();
	}

	public PortOut(String id, String providerId, String goodsId,
			String payType, int number, double price, String time,
			String operatePerson, String comment)
	{
		super(id, providerId, goodsId, payType, number, price, time, operatePerson,
				comment);
		// TODO Auto-generated constructor stub
	}

}
